import sys

from PyQt5 import uic
from PyQt5.QtGui import QPixmap, QPainter, QFont
from PyQt5.QtWidgets import QWidget, QMessageBox, QTableWidgetItem, QFileDialog, QApplication, QToolTip
from PyQt5.QtCore import QTimer, Qt
import os

from PyQt5.uic.properties import QtWidgets

from modules import share_data
# 导入功能函数
from modules.condition_input.funcs.funcs_product_info import widget_fold, get_product_info, update_diagram, check_pdt_define
from modules.condition_input.funcs.ctrl_helper import enable_full_undo
from modules.condition_input.funcs.funcs_cdt_input import load_design_data_if_exists, render_grouped_table, \
    render_coating_table, set_multilevel_headers, apply_table_style, highlight_missing_required_rows, \
    validate_required_fields, import_all_reference_data, save_local_condition_file, save_all_tables, \
    trigger_all_cross_table_relations, apply_design_data_dropdowns, apply_general_data_dropdowns, \
    apply_trail_data_dropdowns, TrailTableComboDelegate, highlight_entire_row, shrink_index_column, shrink_unit_column,\
    get_ref_data_excel_path
from modules.chanpinguanli.chanpinguanli_main import product_manager
from modules.yudingyi.luoshuan import update_user_config_for_2_6_1

product_id = None


def on_product_id_changed(new_id):
    print(f"Received new PRODUCT_ID: {new_id}")
    global product_id
    product_id = new_id


# 测试用产品 ID（真实情况中由外部输入）
product_manager.product_id_changed.connect(on_product_id_changed)


class DesignConditionInputViewer(QWidget):
    def __init__(self, line_tip=None):
        super().__init__()

        current_dir = os.path.dirname(os.path.abspath(__file__))
        ui_path = os.path.join(current_dir, "viewer.ui")
        uic.loadUi(ui_path, self)
        self.line_tip = line_tip

        screen_geometry = QApplication.desktop().screenGeometry()
        screen_width = screen_geometry.width()
        screen_height = screen_geometry.height()
        target_width = int(screen_width * 0.7)
        target_height = int(screen_height * 0.7)
        self.resize(target_width, target_height)
        self.move((screen_width - target_width) // 2, (screen_height - target_height) // 2)

        QToolTip.setFont(QFont("Microsoft YaHei", 12))
        self.graph_product_diagram.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.graph_product_diagram.setAlignment(Qt.AlignCenter)

        self.product_id = product_id
        self._is_valid_product = True
        self._early_tip_msg = ""

        if not self.product_id:
            self._is_valid_product = False
            self._early_tip_msg = "请先至项目管理处选择产品！"
        elif not check_pdt_define(self.product_id):
            self._is_valid_product = False
            self._early_tip_msg = "请先至项目管理处对当前产品进行定义！"
        else:
            self._product_info = get_product_info(self.product_id)
            if not self._product_info:
                self._is_valid_product = False
                self._early_tip_msg = "未找到产品信息，请检查！"

        # 统一处理提示
        if not self._is_valid_product:
            if self.line_tip:
                self.line_tip.setText(self._early_tip_msg)
                self.line_tip.setToolTip(self._early_tip_msg)
            self.setDisabled(True)  # 禁用界面交互
            self._original_pixmap = None
            update_diagram(self.graph_product_diagram, self._original_pixmap)
            return  # 如果你仍想中断后续数据加载逻辑，可以留这个 return，但控件已完整初始化

        self._is_loading_data = True

        self.btn_fold.clicked.connect(self.fold_open)
        self.btn_inputrefdata.clicked.connect(self.on_input_ref_data_clicked)
        self.btn_confirm.clicked.connect(self.check_and_save_data)
        self.btn_output.clicked.connect(self.export_condition_file)
        self.load_product_info(self.product_id, self._product_info)
        self.import_condition_data(self.product_id)

        tables = [
            self.tableWidget_design_data,
            self.tableWidget_general_data,
            self.tableWidget_product_std,
            self.tableWidget_trail_data,
            self.tableWidget_coating_data
        ]
        for table in tables:
            font_metrics = table.fontMetrics()
            header_height = font_metrics.height() + 12
            table.horizontalHeader().setFixedHeight(header_height)

        for table in tables:
            apply_table_style(table)

        if self._is_valid_product:
            # 新增
            for table1 in [
                self.tableWidget_design_data,
                self.tableWidget_general_data,
                self.tableWidget_product_std
            ]:
                shrink_index_column(table1, width=100)

            # 新增
            for table2 in [
                self.tableWidget_design_data,
                self.tableWidget_general_data
            ]:
                shrink_unit_column(table2, width=200)
        for table in tables:
            table.itemSelectionChanged.connect(lambda t=table: highlight_entire_row(t))
        design_config = apply_design_data_dropdowns(product_id=self.product_id)
        general_config = apply_general_data_dropdowns()
        trail_config = apply_trail_data_dropdowns()
        enable_full_undo(self.tableWidget_product_std, self, mode="product")
        enable_full_undo(self.tableWidget_design_data, self, mode="design", dropdown_config=design_config)
        enable_full_undo(self.tableWidget_general_data, self, mode="general", dropdown_config=general_config)
        enable_full_undo(self.tableWidget_coating_data, self, mode="coating")
        trail_delegate = TrailTableComboDelegate(config=trail_config, parent=self.tableWidget_trail_data)
        for col in [2, 4, 5, 7]:
            self.tableWidget_trail_data.setItemDelegateForColumn(col, trail_delegate)

        from modules.condition_input.funcs.ctrl_helper import DropDownClickOnlyFilter
        filter = DropDownClickOnlyFilter(self.tableWidget_trail_data, trail_delegate)
        self.tableWidget_trail_data.viewport().installEventFilter(filter)

        enable_full_undo(self.tableWidget_trail_data, self, mode="trail")
        self.tableWidget_trail_data.viewer = self
        self.tableWidget_trail_data.undo_stack = self.undo_stack

        self._is_loading_data = False



    def fold_open(self):
        widget_fold(self.groupBox_product_info, self.btn_fold)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        update_diagram(self.graph_product_diagram, self._original_pixmap)

    def showEvent(self, event):  # ✅ 新加的方法
        super().showEvent(event)
        if hasattr(self, '_original_pixmap') and self._original_pixmap:
            QTimer.singleShot(100, lambda: update_diagram(
                self.graph_product_diagram, self._original_pixmap))

    def load_product_info(self, product_id, product_info=None):
        try:
            # 如果外部传入了 product_info 就用它，否则重新查
            result = product_info #or get_product_info(product_id)

            if not result:
                # 没查到产品信息，不加载任何数据，显示空图
                self.line_product_code.setText("")
                self.line_product_model.setText("")
                self.line_device_loc_id.setText("")
                self._original_pixmap = None
                update_diagram(self.graph_product_diagram, self._original_pixmap)
                return

            # 设置文本控件
            self.line_product_code.setText(result.get('产品编号', ''))
            self.line_product_model.setText(result.get('产品型号', ''))
            self.line_device_loc_id.setText(result.get('设备位号', ''))

            # 构造产品图路径
            current_dir = os.path.dirname(os.path.abspath(__file__))
            chanpingguanli_dir = os.path.abspath(os.path.join(current_dir, '..', 'chanpinguanli'))
            product_diagram_relpath = result.get('产品示意图', '')
            product_diagram_path = os.path.join(chanpingguanli_dir, product_diagram_relpath)

            # 尝试加载图片
            if os.path.exists(product_diagram_path):
                pixmap = QPixmap(product_diagram_path)
                if not pixmap.isNull():
                    self._original_pixmap = pixmap
                    QTimer.singleShot(0, lambda: update_diagram(self.graph_product_diagram, self._original_pixmap))
                    return

            # 图片加载失败也清空图像并显示文字提示
            self._original_pixmap = None
            update_diagram(self.graph_product_diagram, self._original_pixmap)

        except Exception as e:
            # 防御性兜底
            self._original_pixmap = None
            update_diagram(self.graph_product_diagram, self._original_pixmap)
            print(f"[错误] 加载产品信息失败：{e}")

    def import_condition_data(self, product_id):
        if not product_id:
            return

        result = load_design_data_if_exists(product_id)

        if not result or not result.get("import_status"):
            QMessageBox.information(self, "提示", "未找到设计数据，表格将保持为空。")
            return

        result = load_design_data_if_exists(product_id)
        self.design_data_source = result["data_source_status"]
        print(f"数据来源：{self.design_data_source}")

        # ❗️没有导入数据，提示后返回（错误/空数据情况需要用户知道）
        if not result.get("import_status", False):
            QMessageBox.information(self, "提示", "未在产品设计活动库中找到该产品的设计数据。")
            return

        # ✅ 成功导入时不弹窗，用 print 或 QLabel 替代
        data = result["数据"]
        print("✅ 成功导入产品设计活动数据")  # 或界面提示也可

        self.fill_table_widget(
            self.tableWidget_product_std,
            data["产品标准"]["headers"],
            data["产品标准"]["rows"],
            index_header=data["产品标准"].get("prepend_index_header")
        )
        self.fill_table_widget(
            self.tableWidget_design_data,
            data["设计数据"]["headers"],
            data["设计数据"]["rows"],
            index_header=data["设计数据"].get("prepend_index_header")
        )
        self.fill_table_widget(
            self.tableWidget_general_data,
            data["通用数据"]["headers"],
            data["通用数据"]["rows"],
            index_header=data["通用数据"].get("prepend_index_header")
        )
        set_multilevel_headers(
            self.tableWidget_trail_data,
            top_headers=["接头种类", "检测方法", "壳程", "管程"],
            sub_headers=["", "", "技术等级", "检测比例%", "合格级别", "技术等级", "检测比例%", "合格级别"],
            span_map=[(0, 1), (1, 1), (2, 3), (5, 3)]
        )
        self.render_grouped_table(
            self.tableWidget_trail_data,
            data["检测数据"]["格式化"],
            [
                "接头种类", "检测方法",
                "壳程_技术等级", "壳程_检测比例", "壳程_合格级别",
                "管程_技术等级", "管程_检测比例", "管程_合格级别"
            ],
            group_key_column=0
        )
        # 导入涂漆数据，执行标准/规范从产品标准中取值
        # 在导入涂漆数据之前加入以下代码
        product_std_rows = data["产品标准"]["rows"]
        coating_std_value = ""
        for row in product_std_rows:
            if row.get("规范/标准名称", "").strip() == "涂漆标准":
                coating_std_value = row.get("规范/标准代号", "").strip()
                break
        render_coating_table(self.tableWidget_coating_data, data["涂漆数据"]["格式化"], coating_std_value)
        if hasattr(self, 'undo_stack'):
            self.undo_stack.clear()
        # 专门用于触发“绝热层类型”的联动
        trigger_all_cross_table_relations(self)

    def fill_table_widget(self, table_widget, headers, rows, index_header=None):
        clean_headers = headers.copy()
        if index_header in clean_headers:
            clean_headers.remove(index_header)

        extra_col = 1 if index_header else 0
        table_widget.clear()
        table_widget.setColumnCount(len(clean_headers) + extra_col)
        table_widget.setRowCount(len(rows))

        header_labels = [index_header] + clean_headers if index_header else clean_headers

        for col_index, header_text in enumerate(header_labels):
            display_text = "序号" if index_header and col_index == 0 else header_text
            item = QTableWidgetItem(display_text)
            item.setData(Qt.UserRole, header_text)  # ✅ 存储真实字段名
            item.setTextAlignment(Qt.AlignCenter)
            font = item.font()
            font.setBold(True)
            item.setFont(font)
            item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            table_widget.setHorizontalHeaderItem(col_index, item)

        table_widget.verticalHeader().setVisible(False)

        for row_idx, row in enumerate(rows):
            if index_header:
                index_value = row.get(index_header, "")
                index_item = QTableWidgetItem(str(index_value))
                index_item.setTextAlignment(Qt.AlignCenter)
                index_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                table_widget.setItem(row_idx, 0, index_item)

            for col_idx, key in enumerate(clean_headers):
                value = str(row.get(key, ""))
                item = QTableWidgetItem(value)

                is_name_column = col_idx == 0
                is_code_column = key == "规范/标准代号"
                is_unit_column = key == "参数单位"  # 修改
                if is_name_column:
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                elif is_unit_column:  # 修改
                    item.setTextAlignment(Qt.AlignCenter)  # ✅ 居中
                    item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)  # ✅ 不可编辑
                else:
                    if is_code_column:
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    else:
                        item.setTextAlignment(Qt.AlignCenter)
                    item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEditable | Qt.ItemIsEnabled)

                table_widget.setItem(row_idx, col_idx + extra_col, item)

        # ✅ 仅对涂漆表设置 logical_headers，避免误操作其他表
        if table_widget.objectName() == "tableWidget_coating_data":
            table_widget.logical_headers = [
                "执行标准/规范", "用途", "油漆类别", "颜色", "干膜厚度（μm）", "涂漆面积", "备注"
            ]

        table_widget.resizeColumnsToContents()

    def on_input_ref_data_clicked(self):
        if not getattr(self, "_is_valid_product", True):
            self.line_tip.setText("当前未选择产品，无法导入参考数据")
            self.line_tip.setStyleSheet("color: black;")
            return
        try:
            # 弹出文件选择框
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "选择条件输入数据表",
                "",
                "Excel 文件 (*.xlsx);;所有文件 (*)"
            )
            if not file_path:
                return  # 用户取消选择，直接返回

            # 执行导入操作
            import_all_reference_data(file_path, self)
            QMessageBox.information(self, "成功", "成功导入参考数据！")

        except Exception as e:
            QMessageBox.critical(self, "导入失败", str(e))

    def render_grouped_table(self, table_widget, grouped_data, headers, group_key_column=0):
        render_grouped_table(table_widget, grouped_data, headers, group_key_column)

    # 保存及检查必填项
    def check_and_save_data(self):
        if not getattr(self, "_is_valid_product", True):
            return True  # 空界面不用保存
        try:
            has_missing_dsg, missing_dsg = validate_required_fields(self.tableWidget_design_data, mode="设计数据")
            has_missing_common, missing_common = validate_required_fields(self.tableWidget_general_data,
                                                                          mode="通用数据")

            if has_missing_dsg or has_missing_common:
                missing_fields = [name for _, name in missing_dsg + missing_common]
                msg = "以下必填项：\n" + "、".join(missing_fields) + "\n对应参数值不能为空。"
                QMessageBox.warning(self, "提示", msg)
                highlight_missing_required_rows(self.tableWidget_design_data, missing_dsg)
                highlight_missing_required_rows(self.tableWidget_general_data, missing_common)
                return False

            if not save_local_condition_file(self.product_id, self):
                return False
            update_user_config_for_2_6_1(product_id, json_path="modules/yudingyi/dn_pressure_table.json")
            save_all_tables(self, self.product_id)
            self.line_tip.setText("条件输入数据保存成功！")
            self.line_tip.setToolTip("条件输入数据保存成功！")
            return True

        except Exception as e:
            QMessageBox.critical(self, "保存失败", f"保存数据出错：\n{str(e)}")
            return False

    def export_condition_file(self):
        """
        导出条件输入数据表：先保存至本地文件，然后复制至用户选择的位置。
        """
        from PyQt5.QtWidgets import QFileDialog
        import shutil

        if not getattr(self, "_is_valid_product", True):
            if self.line_tip:
                self.line_tip.setText("❌ 当前未选择有效产品，无法导出。")
            return

        try:
            # 第一步：保存到本地文件
            success = save_local_condition_file(self.product_id, self)
            if not success:
                return

            # 获取本地文件路径
            local_path = get_ref_data_excel_path(self.product_id)

            # 第二步：让用户选择导出路径
            dest_path, _ = QFileDialog.getSaveFileName(
                self,
                "保存条件输入数据表",
                "条件输入数据表.xlsx",
                "Excel 文件 (*.xlsx);;所有文件 (*)"
            )
            if not dest_path:
                if self.line_tip:
                    self.line_tip.setText("导出已取消")
                return

            # 第三步：复制文件到目标位置
            shutil.copyfile(local_path, dest_path)

            message = f"已成功导出文件至: {dest_path}"
            if self.line_tip:
                self.line_tip.setText(message)
                self.line_tip.setToolTip(message)

        except Exception as e:
            err_msg = f"导出文件时出错: {str(e)}"
            if self.line_tip:
                self.line_tip.setText(err_msg[:80])
                self.line_tip.setToolTip(err_msg)
            else:
                QMessageBox.critical(self, "导出失败", err_msg)


