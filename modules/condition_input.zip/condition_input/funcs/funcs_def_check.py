from typing import Tuple
import re

def check_dn(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    if value.strip() == "":
        return "ok", ""
    try:
        dn_val = int(value)
    except ValueError:
        return "error", "输入数据类型有误，请确认后输入"

    if not (150 <= dn_val <= 4000):
        return "error", "输入数值已超过GB/T 151-2014的适用范围，请核对后输入"

    dp_val = None
    dn_shell = None
    dn_tube = None

    if table_widget:
        # 直接取当前行的壳程管程数值
        for row in range(table_widget.rowCount()):
            param_item = table_widget.item(row, 1)
            if not param_item:
                continue
            if param_item.text().strip() == "公称直径*":
                shell_item = table_widget.item(row, 3)  # 壳程列
                tube_item = table_widget.item(row, 4)   # 管程列

                if shell_item and shell_item.text().strip():
                    try:
                        dn_shell = int(shell_item.text().strip())
                    except:
                        pass
                if tube_item and tube_item.text().strip():
                    try:
                        dn_tube = int(tube_item.text().strip())
                    except:
                        pass
                break

        # 提取设计压力
        for row in range(table_widget.rowCount()):
            param_item = table_widget.item(row, 1)
            if param_item and param_item.text().strip() == "设计压力*":
                dp_item = table_widget.item(row, col_index)
                if dp_item and dp_item.text().strip():
                    try:
                        dp_val = float(dp_item.text().strip())
                    except:
                        pass
                break

        if dp_val is not None:
            if dn_val * dp_val > 27000:
                return "error", "公称直径与设计压力乘积超过GB/T 151-2014的适用范围，请核对后输入"

        if dn_shell is not None and dn_tube is not None:
            if dn_shell != dn_tube:
                return "warn", "管、壳程公称直径不一致，请确认"

    return "ok", ""

def check_work_pressure(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“工作压力”的值合法性：
    - 类型 float
    - 必须 < 35
    - 联动检查：
        - 与设计压力*、设计压力2
        - 与进、出口压力差
    """
    if value.strip() == "":
        return "ok", ""
    try:
        wp = float(value)
    except ValueError:
        return "error", "输入数据类型有误，请确认后输入"
    if wp >= 35:
        return "error", "输入数值已超过GB/T 150-2024的适用范围，请核对后输入"
    if not table_widget:
        return "ok", ""

    dp_list = []
    diff_val = None
    for row in range(table_widget.rowCount()):
        name_item = table_widget.item(row, 1)
        if not name_item:
            continue
        name = name_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            val = float(val_item.text())
        except:
            continue
        if name in ["设计压力*", "设计压力2（设计工况2）"]:
            dp_list.append((name, val))
        elif name == "进、出口压力差":
            diff_val = val

    for name, dp in dp_list:
        if wp > 0 and dp > 0:
            if wp >= dp:
                return "error", f"{name} 不应低于工作压力，请核对后输入"
            elif dp / wp > 1.2:
                return "warn", f"{name} 高于工作压力的幅度较大，请确认"
        elif wp < 0 and dp < 0:
            if abs(wp) >= abs(dp):
                return "error", f"{name} 和工作压力均为负压，{name} 应低于工作压力，请核对后输入"
        elif wp * dp < 0:
            return "error", f"{name} 和工作压力必须同正压或同负压，如需校核一正压一负压，请使用多工况模式"

    if diff_val is not None:
        if wp < diff_val:
            return "error", "工作压力不应低于进、出口压力差，请核对后输入"

    return "ok", ""

#已修改
def check_work_temp_in(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    if value.strip() == "":
        return "ok", ""
    try:
        temp = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if not table_widget:
        return "ok", ""

    design_temp = None
    design_temp_2 = None
    min_design_temp = None

    for row in range(table_widget.rowCount()):
        param_item = table_widget.item(row, 1)
        if not param_item:
            continue
        name = param_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            val = float(val_item.text())
        except:
            continue
        if name == "设计温度（最高）*":
            design_temp = val
        elif name == "设计温度2（设计工况2）":
            design_temp_2 = val
        elif name == "最低设计温度":
            min_design_temp = val

    # 新规则：设计温度（最高）* 与工作温度（入口）之间的关系
    if design_temp is not None:
        if design_temp > 0:
            if not (-269 < temp < design_temp):
                if temp >= design_temp:
                    return "error", "工作温度（入口）应小于设计温度（最高）*，请核对后输入"
                else:
                    return "error", "工作温度（入口）应大于 -269℃，请核对后输入"
        elif design_temp < 0:
            if not (design_temp < temp):
                if temp <= design_temp:
                    return "error", "工作温度（入口）应大于设计温度（最高）*，请核对后输入"
                else:
                    return "error", "工作温度（入口）应小于 0℃，请核对后输入"

        # 校验最低设计温度
        if temp < 0 and min_design_temp is not None:
            if temp <= min_design_temp:
                return "error", "最低设计温度应小于工作温度（入口），请核对后输入"

        # 差值超100警告保留
        if abs(design_temp - temp) > 100:
            return "warn", "工作温度（入口）与设计温度（最高）差值较大，请确认"

    # 校验设计工况2
    if design_temp_2 is not None:
        if design_temp_2 > 0:
            if not (-269 < temp < design_temp_2):
                if temp >= design_temp_2:
                    return "error", "工作温度（入口）应小于设计温度2（设计工况2），请核对后输入"
                else:
                    return "error", "工作温度（入口）应大于 -269℃，请核对后输入"
        elif design_temp_2 < 0:
            if not (design_temp_2 < temp):
                if temp <= design_temp_2:
                    return "error", "工作温度（入口）应大于设计温度2（设计工况2），请核对后输入"
                else:
                    return "error", "工作温度（入口）应小于 0℃，请核对后输入"
        # 差值超100警告保留
        if abs(design_temp_2 - temp) > 100:
            return "warn", "工作温度（入口）与设计温度（最高）差值较大，请确认"


    return "ok", ""

#已修改
def check_work_temp_out(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    if value.strip() == "":
        return "ok", ""
    try:
        temp = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if not table_widget:
        return "ok", ""

    design_temp = None
    design_temp_2 = None
    min_design_temp = None

    for row in range(table_widget.rowCount()):
        param_item = table_widget.item(row, 1)
        if not param_item:
            continue
        name = param_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            val = float(val_item.text())
        except:
            continue
        if name == "设计温度（最高）*":
            design_temp = val
        elif name == "设计温度2（设计工况2）":
            design_temp_2 = val
        elif name == "最低设计温度":
            min_design_temp = val

    # 新规则：设计温度（最高）* 与工作温度（入口）之间的关系
    if design_temp is not None:
        if design_temp > 0:
            if not (-269 < temp < design_temp):
                if temp >= design_temp:
                    return "error", "工作温度（出口）应小于设计温度（最高）*，请核对后输入"
                else:
                    return "error", "工作温度（出口）应大于 -269℃，请核对后输入"
        elif design_temp < 0:
            if not (design_temp < temp):
                if temp <= design_temp:
                    return "error", "工作温度（出口）应大于设计温度（最高）*，请核对后输入"
                else:
                    return "error", "工作温度（出口）应小于 0℃，请核对后输入"
        # 校验最低设计温度
        if temp < 0 and min_design_temp is not None:
            if temp <= min_design_temp:
                return "error", "最低设计温度应小于工作温度（出口），请核对后输入"

        # 差值超100警告保留
        if abs(design_temp - temp) > 100:
            return "warn", "工作温度（出口）与设计温度（最高）差值较大，请确认"

    # 校验设计工况2
    if design_temp_2 is not None:
        if design_temp_2 > 0:
            if not (-269 < temp < design_temp_2):
                if temp >= design_temp_2:
                    return "error", "工作温度（出口）应小于设计温度2（设计工况2），请核对后输入"
                else:
                    return "error", "工作温度（出口）应大于 -269℃，请核对后输入"
        elif design_temp_2 < 0:
            if not (design_temp_2 < temp):
                if temp <= design_temp_2:
                    return "error", "工作温度（出口）应大于设计温度2（设计工况2），请核对后输入"
                else:
                    return "error", "工作温度（出口）应小于 0℃，请核对后输入"
        # 差值超100警告保留
        if abs(design_temp_2 - temp) > 100:
            return "warn", "工作温度（出口）与设计温度（最高）差值较大，请确认"

    return "ok", ""

def check_work_pressure_max(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“最高允许工作压力”：
    - 若设计压力 < 0，则禁止填写；
    - 若设计压力 ≥ 0，最高允许工作压力必须 ≥ 设计压力；
    - 类型要求：float
    """

    if value.strip() == "":
        return "ok", ""
    try:
        max_wp = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if not table_widget:
        return "ok", ""
    for row in range(table_widget.rowCount()):
        p_item = table_widget.item(row, 1)
        if p_item and p_item.text().strip() == "设计压力*":
            v_item = table_widget.item(row, col_index)
            if v_item and v_item.text().strip():
                try:
                    dp = float(v_item.text())
                    if dp < 0:
                        return "error", "设计压力为负时不允许填写最高允许工作压力，请核对后输入"
                    if dp > max_wp:
                        return "error", "最高允许工作压力不应低于设计压力，请核对后输入"
                except:
                    pass
            break
    return "ok", ""

def check_tubeplate_design_pressure_gap(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“管板设计压差”：
    1. 类型 float；
    2. 必须 ≥ 0；
    3. 必须 ≤ max(壳程设计压力, 管程设计压力, 差值绝对值)
    返回值：(等级, 提示内容)
    """
    if value.strip() == "":
        return "ok", ""
    try:
        diff_val = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if diff_val < 0:
        return "error", "管板设计压差不能为负，请核对后输入"
    if not table_widget:
        return "ok", ""

    dp_row = None
    for row in range(table_widget.rowCount()):
        param_item = table_widget.item(row, 1)
        if param_item and param_item.text().strip() == "设计压力*":
            dp_row = row
            break
    if dp_row is None:
        return "ok", ""

    shell_col = tube_col = None
    for col in range(table_widget.columnCount()):
        header_item = table_widget.horizontalHeaderItem(col)
        if not header_item:
            continue
        text = header_item.text().strip()
        if text == "壳程数值":
            shell_col = col
        elif text == "管程数值":
            tube_col = col
    if shell_col is None or tube_col is None:
        return "ok", ""

    shell_dp = tube_dp = None
    try:
        s_item = table_widget.item(dp_row, shell_col)
        if s_item and s_item.text().strip():
            shell_dp = float(s_item.text())
    except: pass
    try:
        t_item = table_widget.item(dp_row, tube_col)
        if t_item and t_item.text().strip():
            tube_dp = float(t_item.text())
    except: pass

    if shell_dp is not None and tube_dp is not None:
        limit = max(shell_dp, tube_dp, abs(shell_dp - tube_dp))
        if diff_val > limit:
            return "error", "输入数值有误，请核对后输入"

    return "ok", ""

def check_design_pressure(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“设计压力*”：
    - 类型 float；
    - 范围 ≤ 35 且不在 (-0.02, 0.1)；
    - 联动：工作压力、公称直径、自定义耐压试验压力（卧/立）+ 耐压试验类型
    - 返回值：(等级, 提示语) → error / warn / ok
    """
    if value.strip() == "":
        return "ok", ""
    try:
        dp = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if dp > 35 or (-0.02 < dp < 0.1):
        return "error", "设计压力超过GB/T 150-2024的适用范围，请核对后输入"
    if not table_widget:
        return "ok", ""

    wp = dn = None
    trial_pressure_lying = trial_pressure_stand = trial_type = None

    for row in range(table_widget.rowCount()):
        name_item = table_widget.item(row, 1)
        if not name_item:
            continue
        name = name_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        text = val_item.text().strip()
        try:
            if name == "工作压力":
                wp = float(text)
            elif name == "公称直径*":
                dn = int(text)
            elif name == "自定义耐压试验压力（卧）":
                trial_pressure_lying = float(text)
            elif name == "自定义耐压试验压力（立）":
                trial_pressure_stand = float(text)
            elif name == "耐压试验类型":
                trial_type = text
        except:
            continue

    if wp is not None:
        if dp > 0 and wp > 0 and dp < wp:
            return "error", "设计压力不应低于工作压力，请核对后输入"
        elif dp < 0 and wp < 0 and abs(dp) < abs(wp):
            return "error", "设计压力和工作压力均为负压，设计压力应低于工作压力，请核对后输入"
        elif dp * wp < 0:
            return "error", "设计压力和工作压力必须同正压或同负压，请使用多工况模式"
        elif abs(wp) > 0 and dp / wp > 1.2:
            return "warn", "设计压力高于工作压力的幅度较大，请确认"

    if dn is not None and dp * dn > 27000:
        return "error", "设计压力与公称直径的乘积超过GB/T 151-2014的适用范围，请核对后输入"

    def check_trial_pressure(val):
        if val is None or trial_type is None:
            return "ok"
        if 0.1 <= dp <= 35:
            if trial_type == "液压试验" and val < 1.25 * dp:
                return "warn"
            elif trial_type in ("气压试验", "气液组合试验") and val < 1.1 * dp:
                return "warn"
        elif dp <= -0.02:
            if trial_type == "液压试验" and val < abs(1.25 * dp):
                return "warn"
            elif trial_type in ("气压试验", "气液组合试验") and val < abs(1.1 * dp):
                return "warn"
        return "ok"

    if check_trial_pressure(trial_pressure_lying) == "warn" or check_trial_pressure(trial_pressure_stand) == "warn":
        return "warn", "设计压力和耐压试验压力不符合标准规定，请核对后输入"

    return "ok", ""

def check_design_pressure2(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“设计压力2（设计工况2）”：
    - 类型：float
    - 范围限制：≤35，不能处于 (-0.02, 0.1)
    - 联动校验：
        1. 与工作压力正负联动判断
        2. 与公称直径乘积不超标
    返回值：(等级, 提示内容)
    """

    if value.strip() == "":
        return "ok", ""
    try:
        dp2 = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if dp2 > 35 or (-0.02 < dp2 < 0.1):
        return "error", "设计压力超过GB/T 150-2024的适用范围，请核对后输入"
    if not table_widget:
        return "ok", ""

    wp = dn = None
    for row in range(table_widget.rowCount()):
        name_item = table_widget.item(row, 1)
        if not name_item:
            continue
        name = name_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            if name == "工作压力":
                wp = float(val_item.text())
            elif name == "公称直径*":
                dn = int(val_item.text())
        except:
            continue

    if wp is not None:
        if dp2 > 0 and wp > 0 and dp2 < wp:
            return "error", "设计压力2（设计工况2）不应低于工作压力，请核对后输入"
        elif dp2 < 0 and wp < 0 and abs(dp2) < abs(wp):
            return "error", "设计压力2和工作压力均为负压，设计压力2应低于工作压力，请核对后输入"
        elif dp2 * wp < 0:
            return "error", "设计压力2和工作压力必须同正压或同负压，请使用多工况模式"
        elif abs(wp) > 0 and dp2 / wp > 1.2:
            return "warn", "设计压力2高于工作压力的幅度较大，请确认"

    if dn is not None and dp2 * dn > 27000:
        return "error", "设计压力2与公称直径的乘积超过GB/T 151-2014的适用范围，请核对后输入"

    return "ok", ""

#已修改
def check_design_temp_max(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    if value.strip() == "":
        return "ok", ""

    try:
        temp = float(value)
        if re.match(r'^-?\d+(\.\d{4,})$', value.strip()):
            return "error", "输入数据有误，请确认后输入（最多保留3位小数）"
    except ValueError:
        return "error", "输入数据有误，请确认后输入"

    if not (-269 <= temp <= 900):
        return "error", "设计温度超过GB/T 150-2024的适用范围，请核对后输入"

    if not table_widget:
        return "ok", ""

    work_temp_in = None
    work_temp_out = None

    for row in range(table_widget.rowCount()):
        p_item = table_widget.item(row, 1)
        if not p_item:
            continue
        p_text = p_item.text().strip()
        v_item = table_widget.item(row, col_index)
        if not v_item or not v_item.text().strip():
            continue
        try:
            val = float(v_item.text().strip())
        except ValueError:
            continue

        if p_text == "工作温度（入口）":
            work_temp_in = val
        elif p_text == "工作温度（出口）":
            work_temp_out = val

    # 综合判断：同时存在入口和出口
    if work_temp_in is not None and work_temp_out is not None:
        if temp > 0:
            if work_temp_in <= -269 and work_temp_out <= -269:
                return "error", "工作温度（入口 & 出口）应大于 -269℃，请核对后输入"
            elif work_temp_in >= temp and work_temp_out >= temp:
                return "error", "工作温度（入口 & 出口）应小于设计温度（最高）*，请核对后输入"
            if (temp - work_temp_in > 100 and temp - work_temp_out > 100):
                return "warn", "设计温度（最高）与工作温度（入口 & 出口）差值较大"

        elif temp < 0:
            if work_temp_in >= 0 and work_temp_in >= 0:
                return "error", "工作温度（入口 & 出口）应小于 0℃，请核对后输入"
            elif work_temp_in <= temp and work_temp_out <= temp:
                return "error", "工作温度（入口 & 出口）应大于设计温度（最高）*，请核对后输入"
            if (work_temp_in - temp > 100 and work_temp_out - temp > 100):
                return "warn", "设计温度（最高）与工作温度（入口 & 出口）差值较大"

    # 校验工作温度（入口）与设计温度（最高）* 的关系
    if work_temp_in is not None:
        if temp > 0:
            if not (-269 < work_temp_in < temp):
                if work_temp_in >= temp:
                    return "error", "工作温度（入口）应小于设计温度（最高）*，请核对后输入"
                else:
                    return "error", "工作温度（入口）应大于 -269℃，请核对后输入"
        elif temp < 0:
            if not (temp < work_temp_in < 0):
                if work_temp_in <= temp:
                    return "error", "工作温度（入口）应大于设计温度（最高）*，请核对后输入"
                else:
                    return "error", "工作温度（入口）应小于 0℃，请核对后输入"
        if abs(temp - work_temp_in) > 100:
            return "warn", "设计温度（最高）与工作温度（入口）差值较大"

    # 校验工作温度（出口）与设计温度（最高）* 的关系
    if work_temp_out is not None:
        if temp > 0:
            if not (-269 < work_temp_out < temp):
                if work_temp_out >= temp:
                    return "error", "工作温度（出口）应小于设计温度（最高）*，请核对后输出"
                else:
                    return "error", "工作温度（出口）应大于 -269℃，请核对后输出"
        elif temp < 0:
            if not (temp < work_temp_out < 0):
                if work_temp_out <= temp:
                    return "error", "工作温度（出口）应大于设计温度（最高）*，请核对后输出"
                else:
                    return "error", "工作温度（出口）应小于 0℃，请核对后输出"
        if abs(temp - work_temp_out) > 100:
            return "warn", "设计温度（最高）与工作温度（出口）差值较大"

    return "ok", ""

#已修改
def check_design_temp_max2(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“设计温度2（设计工况2）”：
    - 类型 float，最多保留3位小数；
    - 范围限制 [-269, 900]；
    - 联动判断：不得低于“工作温度（入口）/（出口）”，差值 > 100 提醒
    """

    if value.strip() == "":
        return "ok", ""
    try:
        temp = float(value)
        if re.match(r'^-?\d+\.\d{4,}$', value.strip()):
            return "error", "输入数据有误，请确认后输入（最多保留3位小数）"
    except ValueError:
        return "error", "输入数据有误，请确认后输入"
    if not (-269 <= temp <= 900):
        return "error", "设计温度超过GB/T 150-2024的适用范围，请核对后输入"
    if not table_widget:
        return "ok", ""

    work_in = work_out = None
    for row in range(table_widget.rowCount()):
        p_item = table_widget.item(row, 1)
        if not p_item:
            continue
        name = p_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            val = float(val_item.text())
        except:
            continue

        if name == "工作温度（入口）":
            work_in = val
        elif name == "工作温度（出口）":
            work_out = val

    work_max = max(filter(None, [work_in, work_out]), default=None)
    if work_max is not None:
        if temp < work_max:
            return "error", "设计温度2（设计工况2）不应低于工作温度，请核对后输入"
        elif temp - work_max > 100:
            return "warn", "设计温度2（设计工况2）与工作温度差值较大，请确认"

    return "ok", ""
#已修改
def check_design_temp_min(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“最低设计温度”：
    1. 类型 float；
    2. 值必须 ≥ -269；
    3. 联动判断：
       - 最低设计温度应低于“工作温度（入口）”、“工作温度（出口）”
    """
    if value.strip() == "":
        return "ok", ""
    try:
        temp = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if temp < -269:
        return "error", "设计温度超过GB/T 150-2024的适用范围，请核对后输入"
    if not table_widget:
        return "ok", ""

    work_in = work_out = None
    for row in range(table_widget.rowCount()):
        p_item = table_widget.item(row, 1)
        if not p_item:
            continue
        name = p_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            v = float(val_item.text())
        except:
            continue

        if name == "工作温度（入口）":
            work_in = v
        elif name == "工作温度（出口）":
            work_out = v

    work_min = min(filter(None, [work_in, work_out]), default=None)
    if work_min is not None and temp >= work_min and work_min==work_in:
        return "error", "最低设计温度应小于工作温度（入口）,请核对后输入"
    if work_min is not None and temp >= work_min and work_min==work_out:
        return "error", "最低设计温度应小于工作温度（出口）,请核对后输入"

    return "ok", ""

def check_in_out_pressure_gap(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“进、出口压力差”：
    1. 类型 float；
    2. 值必须 ≥ 0；
    3. 不得高于当前壳程/管程的“工作压力”
    """
    if value.strip() == "":
        return "ok", ""
    try:
        diff_val = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"

    if diff_val < 0:
        return "error", "输入数值不能为负，请核对后输入"

    if not table_widget:
        return "ok", ""

    work_pressure = None
    for row in range(table_widget.rowCount()):
        param_item = table_widget.item(row, 1)
        if not param_item:
            continue
        if param_item.text().strip() == "工作压力":
            val_item = table_widget.item(row, col_index)
            if val_item and val_item.text().strip():
                try:
                    work_pressure = float(val_item.text())
                    break
                except:
                    pass

    if work_pressure is not None and diff_val > work_pressure:
        return "error", "进、出口压力差不应高于工作压力，请核对后输入"

    return "ok", ""

def check_trail_stand_pressure_medium_density(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“耐压试验介质密度”：
    - 必须为 float；
    - 必须 > 0
    """
    if value.strip() == "":
        return "ok", ""
    try:
        density = float(value)
    except ValueError:
        return "error", "输入数据类型有误，请确认后输入"
    if density <= 0:
        return "error", "输入数值有误，请核对后输入"
    return "ok", ""

def check_insulation_layer_thickness(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“绝热层厚度”：
    - 必须为 float；
    - 必须 > 0 mm
    """
    if value.strip() == "":
        return "ok", ""
    try:
        thickness = float(value)
    except ValueError:
        return "error", "输入数据类型有误，请确认后输入"
    if thickness <= 0:
        return "error", "输入数值有误，请核对后输入"
    return "ok", ""

def check_insulation_material_density(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“绝热材料密度”：
    - 类型：float；
    - 范围：> 0 kg/m³
    """
    if value.strip() == "":
        return "ok", ""
    try:
        density = float(value)
    except ValueError:
        return "error", "输入数据类型有误，请确认后输入"
    if density <= 0:
        return "error", "输入数值有误，请核对后输入"
    return "ok", ""

#改
def check_def_trail_stand_pressure_lying(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“自定义耐压试验压力（卧）”：
    - 类型：float
    - 联动参数：
        - 所在压力腔“设计压力*”
        - “耐压试验类型”
    - 判定逻辑：
        1）设计压力在 [0.1, 35] MPa 且为正时：
            液压试验      ≥ 1.25 * 设计压力
            气压/气液组合 ≥ 1.1 * 设计压力
        2）设计压力 ≤ -0.02 MPa（负压）时：
            液压试验      ≥ abs(1.25 * 设计压力)
            气压/气液组合 ≥ abs(1.1 * 设计压力)
    """
    if value.strip() == "":
        return "ok", ""
    try:
        pressure_val = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if not table_widget:
        return "ok", ""

    if pressure_val<0:
        return "error", "实验压力输入不能为负值"


    design_pressure = None
    pressure_type = None
    for row in range(table_widget.rowCount()):
        name_item = table_widget.item(row, 1)
        if not name_item:
            continue
        name = name_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            val = val_item.text().strip()
            if name == "设计压力*":
                design_pressure = float(val)
            elif name == "耐压试验类型*":
                pressure_type = val
        except:
            continue

    if design_pressure is None or pressure_type is None:
        return "ok", ""

    if 0.1 <= design_pressure <= 35:
        if pressure_type == "液压试验" and pressure_val < 1.25 * design_pressure:
            return "error", "耐压试验压力低于标准规定，请确认后输入"
        elif pressure_type in ("气压试验", "气液组合试验") and pressure_val < 1.1 * design_pressure:
            return "error", "耐压试验压力低于标准规定，请确认后输入"
    elif design_pressure <= -0.02:
        if pressure_type == "液压试验" and pressure_val < abs(1.25 * design_pressure):
            return "error", "耐压试验压力低于标准规定，请确认后输入"
        elif pressure_type in ("气压试验", "气液组合试验") and pressure_val < abs(1.1 * design_pressure):
            return "error", "耐压试验压力低于标准规定，请确认后输入"

    return "ok", ""

#改
def check_def_trail_stand_pressure_stand(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“自定义耐压试验压力（立）”：
    - 类型：float
    - 联动参数：
        - 所在压力腔“设计压力*”
        - “耐压试验类型”
    - 判定逻辑：
        1）设计压力在 [0.1, 35] MPa 且为正时：
            液压试验      ≥ 1.25 * 设计压力
            气压/气液组合 ≥ 1.1 * 设计压力
        2）设计压力 ≤ -0.02 MPa（负压）时：
            液压试验      ≥ abs(1.25 * 设计压力)
            气压/气液组合 ≥ abs(1.1 * 设计压力)
    """
    if value.strip() == "":
        return "ok", ""
    try:
        pressure_val = float(value)
    except:
        return "error", "输入数据类型有误，请确认后输入"
    if not table_widget:
        return "ok", ""
    if pressure_val<0:
        return "error", "实验压力输入不能为负值"
    design_pressure = None
    pressure_type = None
    for row in range(table_widget.rowCount()):
        name_item = table_widget.item(row, 1)
        if not name_item:
            continue
        name = name_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        try:
            val = val_item.text().strip()
            if name == "设计压力*":
                design_pressure = float(val)
            elif name == "耐压试验类型*":
                pressure_type = val
        except:
            continue

    if design_pressure is None or pressure_type is None:
        return "ok", ""

    if 0.1 <= design_pressure <= 35:
        if pressure_type == "液压试验" and pressure_val < 1.25 * design_pressure:
            return "error", "耐压试验压力低于标准规定，请确认后输入"
        elif pressure_type in ("气压试验", "气液组合试验") and pressure_val < 1.1 * design_pressure:
            return "error", "耐压试验压力低于标准规定，请确认后输入"
    elif design_pressure <= -0.02:
        if pressure_type == "液压试验" and pressure_val < abs(1.25 * design_pressure):
            return "error", "耐压试验压力低于标准规定，请确认后输入"
        elif pressure_type in ("气压试验", "气液组合试验") and pressure_val < abs(1.1 * design_pressure):
            return "error", "耐压试验压力低于标准规定，请确认后输入"

    return "ok", ""

def check_trail_stand_pressure_type(value, tip_widget, param_name, column_name, table_widget, col_index) -> Tuple[str, str]:
    """
    校验“耐压试验类型*”：
    - 类型：字符串，支持“液压试验”、“气压试验”、“气液组合试验”
    - 联动项：设计压力* + 自定义耐压试验压力（卧/立）
    - 反向校验：根据设计压力反推试验压力是否合格
    """
    if value.strip() == "":
        return "ok", ""
    trial_type = value.strip()
    valid_types = ["液压试验", "气压试验", "气液组合试验"]
    if trial_type not in valid_types:
        return "error", "耐压试验类型输入有误，请从下拉选项选择"
    if not table_widget:
        return "ok", ""

    dp = trial_pressure_lying = trial_pressure_stand = None
    for row in range(table_widget.rowCount()):
        name_item = table_widget.item(row, 1)
        if not name_item:
            continue
        name = name_item.text().strip()
        val_item = table_widget.item(row, col_index)
        if not val_item or not val_item.text().strip():
            continue
        text = val_item.text().strip()
        try:
            if name == "设计压力*":
                dp = float(text)
            elif name == "自定义耐压试验压力（卧）":
                trial_pressure_lying = float(text)
            elif name == "自定义耐压试验压力（立）":
                trial_pressure_stand = float(text)
        except:
            continue

    def is_valid(trial_val):
        if dp is None or trial_val is None:
            return True
        if 0.1 <= dp <= 35:
            return trial_val >= (1.25 * dp if trial_type == "液压试验" else 1.1 * dp)
        elif dp <= -0.02:
            return trial_val >= (abs(1.25 * dp) if trial_type == "液压试验" else abs(1.1 * dp))
        return True

    if not is_valid(trial_pressure_lying) or not is_valid(trial_pressure_stand):
        return "warn", "耐压实验类型和耐压试验压力不符合标准规定，请核对后输入"

    return "ok", ""